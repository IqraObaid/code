
<?php
function AllWorkShop(){
    GLOBAL $connection;
    $query="SELECT * FROM workshop";
    $workshop_query=mysqli_query($connection,$query);
    return $workshop_query;
}

function GetUserId($username){
    GLOBAL $connection;
    $query="SELECT id FROM signin WHERE username='$username'";
    $id_query=mysqli_query($connection,$query);
    $row=mysqli_fetch_assoc($id_query);
    return $row['id'];
}


function CurrentProgress($username){
    GLOBAL $connection;
    $query="SELECT * FROM signin WHERE username='$username'";
    $current_point_progress=mysqli_query($connection,$query);
    $row=mysqli_fetch_assoc($current_point_progress);
    $current_progress=$row['current_progress'];
    return $current_progress;

}
function BadgesEarned($username){
    GLOBAL $connection;
    $query="SELECT * FROM signin WHERE username='$username'";
    $current_point_progress=mysqli_query($connection,$query);
    $row=mysqli_fetch_assoc($current_point_progress);
    $badges_earned=$row['badges_earned'];
    return $badges_earned;

}

function GetAllTeams($userid){
    GLOBAL $connection;
    $query="SELECT * FROM team WHERE team_lead_id='$userid'";
    $team_query=mysqli_query($connection,$query);
    return $team_query;
}

function GetTeamMembers($team_id){
    GLOBAL $connection;
    $query="SELECT * FROM signin WHERE team='$team_id'";
    $team_member_query=mysqli_query($connection,$query);
    return $team_member_query;
}
function GetAllDevelopers(){
    GLOBAL $connection;
    $query="SELECT * FROM signin WHERE role='developer'";
    $developer_query=mysqli_query($connection,$query);
    return $developer_query;
}
function GetAllSubprojects($userid){
    GLOBAL $connection;
    $query="SELECT * FROM sub_project WHERE sub_project_assigned_to='$userid'";
     $project_query=mysqli_query($connection,$query);
     return $project_query;
}
function GetAllTasks($userid){
    GLOBAL $connection;
    $query="SELECT * FROM task WHERE task_assignee='$userid'";
     $project_query=mysqli_query($connection,$query);
     return $project_query;
}

function get_user_subproject_total_points($userid)
{
    GLOBAL $connection;
   $query="SELECT SUM(sub_project_points) AS total_points,s.id
FROM sub_project t,signin s 
WHERE s.id=t.sub_project_assigned_to
AND t.sub_project_assigned_to = '$userid'";
$reward=mysqli_query($connection,$query);
$row=mysqli_fetch_assoc($reward);

    return $row['total_points'];
}

function redirect($url){
    header('Location: $url');
}
function update_total_points($userid,$ta)
{
    GLOBAL $connection;
    
$query="select * from task where task_id=$ta";
 $reward=mysqli_query($connection,$query);
 $row=mysqli_fetch_assoc($reward);
 $user=$row['task_assigned_to'];

 $points=$row['task_points'];
 $query="select * from signin where id=$user";
 $get_user_id=mysqli_query($connection,$query);
 $row=mysqli_fetch_assoc($get_user_id);
 $total_points=$row['total_points'];
 $query="select ($total_points+ $points) as total_points from signin where id=$user";
 $add_points=mysqli_query($connection,$query);
 $row=mysqli_fetch_assoc($add_points);
 $points=$row['total_points'];
 echo $points;
 $query="update signin set total_points=$points where id=$user";
 $point=mysqli_query($connection,$query);
 if(!$point){
    die("Query Failed".mysqli_error($connection));
  }
}
?>