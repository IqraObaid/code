<?php
  $points=CurrentPoints($username);
  $current_point=$points%1000;
  $current_progres=(($current_point*100)/1000);
  $level=1+floor($points/1000);
?>


<div class="relative w-75 ">
            <div class="p-2 ">
              <span class="p-1 w-25 rounded px-2" style=" background-color: rgb(39,41,61); color: rgb(248,255,255);">
                Level <?php echo $level?>
              </span>
            </div>
            
            <div class="progress mt-2" style="height: 40px;" >
              <div class="progress-bar bg-danger" style="width:<?php echo $current_progres?>%; height: 40px;"><?php echo $current_point?></div>
            </div>

              </div>
        </div>
        