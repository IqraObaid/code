<?php 
include '../includes/connection.php';
include 'includes/functions.php';
?>
<?php
session_start();
$username=$_SESSION['id'];
 if(!$_SESSION['id']){
  include '../includes/session_destroy.php';
 }
if(isset($_POST['logout'])){
  include '../includes/session_destroy.php';
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <link rel="stylesheet" href="../asset/style.css">
  <title>
    Dashboard
  </title>
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet" />
  <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
  <!-- Nucleo Icons -->
  <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/black-dashboard.css?v=1.0.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
  <script src="https://kit.fontawesome.com/1493114a02.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  
  <style>
    svg.radial-progress {
  height: auto;
  max-width: 180px;
  padding: 1em;
  transform: rotate(-90deg);
  width: 100%;
}

svg.radial-progress circle {
  fill: rgba(0,0,0,0);
  stroke: #fff;
  stroke-dashoffset: 219.91148575129; /* Circumference */
  stroke-width: 10;
}

svg.radial-progress circle.incomplete { opacity: 0.25; }

svg.radial-progress circle.complete { stroke-dasharray: 219.91148575129; /* Circumference */ }

svg.radial-progress text {
  fill: #fff;
  font: 400 1em/1 'Oswald', sans-serif;
  text-anchor: middle;
}

/*** COLORS ***/
/* Primary */

svg.radial-progress:nth-of-type(6n+1) circle { stroke: #83e4e2; }

/* Secondary */

svg.radial-progress:nth-of-type(6n+2) circle { stroke: #83e4e2; }

  </style>
 
</head>

<body class="">
  <div class="wrapper">
    <?php include 'includes/navigation_sidebar.php'?>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle d-inline">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:void(0)">Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse" id="navigation">
            <ul class="navbar-nav ml-auto">
              <li class="search-bar input-group">
                <?php include '../includes/search.php'?>
              </li>
              
              <li class="dropdown nav-item">
                <?php include '../includes/profile_image.php'?>
                  <?php include '../includes/profile_dropdown.php'?>
              </li>
              <li class="separator d-lg-none"></li>
            </ul>
          </div>
        </div>
      </nav>
      <div class="modal modal-search fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="searchModal" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="SEARCH">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <i class="tim-icons icon-simple-remove"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
      <!-- End Navbar -->
      <div class="content ">
        
        <div class="d-flex justify-content-center">
        <div class="mt-4 row ">

          <div class="col-md-8">
          <h1>Workshops</h1>
            <div class="border p-2 rounded" style=" background-color: rgb(39,41,61); border-color: rgb(39,41,61) !important; ">
            <table class="table">
              <tr>
                <th>Title</th>
                <th>Date</th>
                <th>Starting Time</th>
                <th>End Time</th>
                <th>Online</th>
                <th>Venue</th>
                <th>Test</th>

              </tr>
              <tbody>
<?php
  $all_workshop_query=AllWorkShop();
  while($row=mysqli_fetch_assoc($all_workshop_query)){
    $id=$row['id'];
    $title=$row['title'];
    $date=$row['date'];
    $start_time=$row['start_time'];
    $end_time=$row['end_time'];
    $online_link=$row['link'];
    $venue=$row['venue'];


?>
                <tr>
                  <td><?php echo $title ?></td>
                  <td><?php echo $date ?></td>
                  <td><?php echo $start_time ?></td>
                  <td><?php echo $end_time ?></td>
                  <td><?php echo $online_link ?></td>
                  <td><?php echo $venue ?></td>
                  <td><a href="workshop_test.php?id=<?php echo $id?>" class="btn btn-warning text-xs">Test</a></td>
                </tr>
<?php } ?>
              </tbody>

            </table>
              
        
        </div>


        <!-- progress end -->

          </div>
<!-- col-8 end -->
          <div class="col-md-4">
            <div class="mt-4 p-2 rounded " style=" background-color: rgb(39,41,61) ;">
              <div class="mt-2 px-4 rounded"  >
                <span class="font-weight-bold text-lg" style=" color: rgb(248,255,255) ;">Leaderboard</span>
              </div>
              <?php include '../includes/leaderboard_dashboard.php'?>
              <div class=" ">
                <div class="mt-2 d-flex ">
                  <img class="w-10 h-10 object-cover rounded-full" src="../images/<?php echo $images[0]?>" alt="">
                  <span class="p-2" style=" color: rgb(248,255,255) ;"><?php echo $names_array[0]?></span>
                </div>
                <div class="text-right">
                  <span style=" color: rgb(248,255,255) ;" class="text-xs font-semibold inline-block text-success">
                    1st
                  </span>
                </div>
             
              <div class="overflow-hidden h-2 mb-2 text-xs flex rounded bg-green-200">
                <div style="width:80%"
                  class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-success">
                </div>
              </div>
              </div>
              <div class="">
                <div class="mt-2 d-flex ">
                  <img class="w-10 h-10 object-cover rounded-full" src="../images/<?php echo $images[1]?>" alt="">
                  <span class="p-2" style=" color: rgb(248,255,255) ;"><?php echo $names_array[1]?></span>
                </div>
                <div class="text-right">
                  <span class="text-xs font-semibold inline-block text-indigo-600" style=" color: rgb(248,255,255) ;">
                    2nd
                  </span>
                </div>
             
              <div class="overflow-hidden h-2 mb-2 text-xs flex rounded bg-indigo-200">
                <div style="width:60%"
                  class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-indigo-500">
                </div>
              </div>
              </div>
              <div class="">
                <div class="mt-2 d-flex ">
                  <img class="w-10 h-10 object-cover rounded-full" src="../images/<?php echo $images[2]?>" alt="">
                  <span class="p-2" style=" color: rgb(248,255,255) ;"><?php echo $names_array[2]?></span>
                </div>
                <div class="text-right">
                  <span class="text-xs font-semibold inline-block text-red-600" style=" color: rgb(248,255,255) ;">
                    3rd
                  </span>
                </div>
             
              <div class="overflow-hidden h-2 mb-2 text-xs flex rounded bg-red-200">
                <div style="width:40%"
                  class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-red-500">
                </div>
              </div>
              </div>
              
             
          
            </div>
            <div class="mt-4 p-2 rounded" style=" background-color :  rgb(39,41,61);">
              <div class="mt-2 px-4 rounded"  >
                <span class="font-weight-bold text-lg" style=" color: rgb(248,255,255) ;">My Challanges</span>
              </div>
             
              
              
              
             
          
            </div>
            <?php include "../includes/get_badge_dashboard.php"?>

            <?php include "../includes/earn_reward_dashboard.php"?>
          </div>
          
        </div>
        
        
      </div>
      <!-- content div end -->
     
    </div>
  
    
  </div>

  
  
  <div class="fixed-plugin">
    <div class="dropdown show-dropdown">
      <a href="#" data-toggle="dropdown">
        <i class="fa fa-cog fa-2x"> </i>
      </a>
      <ul class="dropdown-menu">
        <li class="header-title"> Sidebar Background</li>
        <li class="adjustments-line">
          <a href="javascript:void(0)" class="switch-trigger background-color">
            <div class="badge-colors text-center">
              <span class="badge filter badge-primary active" data-color="primary"></span>
              <span class="badge filter badge-info" data-color="blue"></span>
              <span class="badge filter badge-success" data-color="green"></span>
             
            </div>
            <div class="clearfix"></div>
          </a>
        </li>
        <li class="adjustments-line text-center color-change">
          <span class="color-label">LIGHT MODE</span>
          <span class="badge light-badge mr-2"></span>
          <span class="badge dark-badge ml-2"></span>
          <span class="color-label">DARK MODE</span>
        </li>
      
      </ul>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <!-- Place this tag in your head or just before your close body tag. -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Black Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/black-dashboard.min.js?v=1.0.0"></script><!-- Black Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
</body>

</html>