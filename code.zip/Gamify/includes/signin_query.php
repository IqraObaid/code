<?php
if(isset($_POST['submit'])){
        $username=$_POST['username'];
        $password=$_POST['password'];

        $query="SELECT * FROM signin WHERE username='$username' AND password='$password'";
        $signin_query=mysqli_query($connection,$query);
        $rows=mysqli_num_rows($signin_query);
        if($rows==1){
            include 'session_start.php';
            $row=mysqli_fetch_assoc($signin_query);
            switch ($row['role']){
            case "developer":
                header('Location: dashboard.php');
                break;
            case "team_lead":
                header('Location: ../TL/dashboard.php');
                break;
            case "PM":
                header('Location: ../PM/dashboard.php');
                break;
            case "HR":
                header('Location: ../HR/dashboard.php');
                break;
            case "BDM":
                header('Location: ../BDM/dashboard.php');
                break;
            case "CEO":
                header('Location: ../CEO/dashboard.php');
                break;
            default:
            }
                
        }
        else{
            echo "Invalid username or password";
        }
    }

    ?>