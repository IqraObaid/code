<button class="btn btn-link" id="search-button" data-toggle="modal" data-target="#searchModal"><i class="tim-icons icon-zoom-split" ></i>
    <span class="d-lg-none d-md-block">Search</span>
</button>