<?php
if(isset($_POST['submit'])){
        $username=$_POST['username'];
        $password=$_POST['password'];

        $query="SELECT * FROM signin WHERE username='$username' AND password='$password'";
        $signin_query=mysqli_query($connection,$query);
        $rows=mysqli_num_rows($signin_query);
        if($rows==1){
            include 'session_start.php';
            header('Location: dashboard.php');
        }
        else{
            echo "Invalid username or password";
        }
    }

    ?>