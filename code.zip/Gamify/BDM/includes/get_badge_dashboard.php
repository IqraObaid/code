<div class="mt-4 p-2 rounded" style=" background-color :  rgb(39,41,61);">
              <div class="mt-2 px-4 rounded"  >
                <span class="font-weight-bold text-lg" style=" color: rgb(248,255,255) ;">Your Points</span>
              </div>
              <div class="d-flex justify-content-center mt-4">
                <i class="fas fa-coins text-4xl mr-3" style="color: rgb(202, 177, 62);"></i>
                <span class="text-4xl" style="color: rgb(248,255,255);">1000</span>
              </div>
              <div class="d-flex justify-content-center mt-4">
              
                <span class="text-sm d-flex" style="color: rgb(248,255,255);">Exchange Your Points </span>
           
              </div>
              <div class="d-flex justify-content-center">
              
             
                <span class="text-sm d-flex" style="color: rgb(248,255,255);"> To Get Badges!</span>
              </div>
              <div class="d-flex justify-content-center mt-2 mb-2">
              
             
                <button type="button" class="btn btn-success text-sm">Spend Points</button>
              </div>
          
            </div>