<?php
include '../includes/connection.php';
include '../includes/functions.php';

session_start();
$username=$_SESSION['id'];
 if(!$_SESSION['id']){
  include '../includes/session_destroy.php';
 }
if(isset($_POST['logout'])){
  include '../includes/session_destroy.php';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    Leaderboards
  </title>
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,600,700,800" rel="stylesheet" />
  <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
  <!-- Nucleo Icons -->
  <link href="../assets/css/nucleo-icons.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="../assets/css/black-dashboard.css?v=1.0.0" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

  <script src="https://kit.fontawesome.com/1493114a02.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="../asset/style.css">
  
</head>

<body class="">
  <div class="wrapper">
  <?php include '../includes/navigation_sidebar.php'?>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle d-inline">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:void(0)">Leaderboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse" id="navigation">
            <ul class="navbar-nav ml-auto">
              <li class="search-bar input-group">
              <?php include '../includes/search.php'?>
              </li>
              
              <li class="dropdown nav-item">
              <?php include '../includes/profile_image.php'?>
                <?php include '../includes/profile_dropdown.php'?>
              </li>
              <li class="separator d-lg-none"></li>
            </ul>
          </div>
        </div>
      </nav>
      <div class="modal modal-search fade" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="searchModal" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="SEARCH">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <i class="tim-icons icon-simple-remove"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
      <!-- End Navbar -->
      <div class="content">
        
        <div class="d-flex justify-content-center">

        <?php include '../includes/progress_bar.php'?>
        <div class="mt-4 px-4 align-items-center display-inline">
            <span class="font-weight-bold" style="font-size: 20px ; color: rgb(248,255,255);">Leaderboard</span>
            
          </div>

<?php
$query="SELECT * FROM signin ORDER BY total_points DESC LIMIT 5";
$leader_board_query=mysqli_query($connection,$query);
$names_array=[];
$total_points_array=[];
$images=[];

while($row=mysqli_fetch_assoc($leader_board_query)){
  array_push($names_array,$row['name']);
  array_push($total_points_array,$row['total_points']);
  array_push($images,$row['image']);
}

?>
        <div class="row ">
            
            <div class="col-md-4">
                <div class="max-w-md py-4 px-8 bg-white shadow-lg rounded-lg my-5" style="background-color: rgb(39,41,61) !important;">
                    <div class="flex justify-end  -mt-16">
                        <img class="w-20 h-20 object-cover rounded-full border-2 p-2" style="border:6px solid rgb(30,30,43); background-color: rgb(39,41,61);" src="https://creazilla-store.fra1.digitaloceanspaces.com/emojis/56770/1st-place-medal-emoji-clipart-md.png">
                      </div>
                    <div>
                      <span class=" text-3xl" style="color: rgb(248,255,255);"><?php echo $names_array[0]?></span>
                      </div>
                      <div class="d-flex justify-center ml-20">
                        <span class=" text-3xl font-bold " style="color: rgb(248,255,255);">1st</span>
                    
                      </div>
                      <div class="text-right">
                        <span class="text-xs font-semibold inline-block text-indigo-600" style=" color: rgb(248,255,255) ;">
                        <?php echo $total_points_array[0]?>
                        </span>
                      </div>
                   
                    <div class="overflow-hidden h-2 mb-2 mt-2 text-xs flex rounded bg-green-200">
                      <div style="width:90%"
                        class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-500">
                      </div>
                    
                  </div>
            </div>
          
        </div>
        <div class="col-md-4">
            <div class="max-w-md py-4 px-8 bg-white shadow-lg rounded-lg my-5" style="background-color: rgb(39,41,61) !important;">
                <div class="flex justify-end -mt-16">
                    <img class="w-20 h-20 object-cover rounded-full border-2 p-2" style="border:6px solid rgb(30,30,43); background-color: rgb(39,41,61);" src="https://creazilla-store.fra1.digitaloceanspaces.com/emojis/57094/2nd-place-medal-emoji-clipart-md.png">
                  </div>
                <div>
                  <span class=" text-3xl" style="color: rgb(248,255,255);"><?php echo $names_array[1]?></span>
                  </div>
                  <div class="d-flex justify-center ml-20">
                    <span class=" text-3xl font-bold " style="color: rgb(248,255,255);">2nd</span>
                
                  </div>
                  <div class="text-right">
                    <span class="text-xs font-semibold inline-block text-indigo-600" style=" color: rgb(248,255,255) ;">
                    <?php echo $total_points_array[1]?>
                    </span>
                  </div>
               
                <div class="overflow-hidden h-2 mb-2 mt-2 text-xs flex rounded bg-indigo-200">
                  <div style="width:70%"
                    class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-indigo-500">
                  </div>
                
              </div>
        </div>
        
        
          
       
    </div>
    <div class="col-md-4 ">
        <div class="max-w-md py-4 px-8 bg-white shadow-lg rounded-lg my-5" style="background-color: rgb(39,41,61) !important;">
            <div class="flex justify-end -mt-16">
                <img class="w-20 h-20 object-cover rounded-full border-2 p-2" style="border:6px solid rgb(30,30,43); background-color: rgb(39,41,61);" src="https://creazilla-store.fra1.digitaloceanspaces.com/emojis/57143/3rd-place-medal-emoji-clipart-md.png">
              </div>
            <div>
              <span class=" text-3xl" style="color: rgb(248,255,255);"><?php echo $names_array[2]?></span>
              </div>
              <div class="d-flex justify-center ml-20">
                <span class=" text-3xl font-bold " style="color: rgb(248,255,255);">3rd</span>
            
              </div>
              <div class="text-right">
                <span class="text-xs font-semibold inline-block text-gray-600" style=" color: rgb(248,255,255) ;">
                <?php echo $total_points_array[2]?>
                </span>
              </div>
           
            <div class="overflow-hidden h-2 mb-2 mt-2 text-xs flex rounded bg-gray-200">
              <div style="width:50%"
                class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-gray-500">
              </div>
            
          </div>
    </div>
    
    
      
   
</div>
<?php


?>
        
      </div>

      <div class="row">
          <div class="col-md-8">
              <div class=" p-2 rounded " style=" background-color: rgb(39,41,61) ;">
              <div class="mt-2 px-4 rounded"  >
                <span class="font-weight-bold text-lg" style=" color: rgb(248,255,255) ;">Names</span>
              </div>
              <div class="flex-col justify-center p-4">
                <div class=" ">
                    <div class="mt-4 d-flex ">
                      <img class="w-10 h-10 object-cover rounded-full" src="../images/<?php echo $images[0]?>" alt="">
                      <span class="p-2" style=" color: rgb(248,255,255) ;"><?php echo $names_array[0]."(".$total_points_array[0]."points)"?></span>
                    </div>
                    <div class="text-right">
                      <span style=" color: rgb(248,255,255) ;" class="text-xs font-semibold inline-block text-success">
                        1st
                      </span>
                    </div>
                 
                  <div class="overflow-hidden h-2 mb-2 text-xs flex rounded bg-green-200">
                    <div style="width:90%"
                      class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-500">
                    </div>
                  </div>
                  </div>
                  <div class="">
                    <div class="mt-4 d-flex ">
                      <img class="w-10 h-10 object-cover rounded-full" src="../images/<?php echo $images[1]?>" alt="">
                      <span class="p-2" style=" color: rgb(248,255,255) ;"><?php echo $names_array[1]."(".$total_points_array[1]."points)"?></span>
                    </div>
                    <div class="text-right">
                      <span class="text-xs font-semibold inline-block text-indigo-600" style=" color: rgb(248,255,255) ;">
                        2nd
                      </span>
                    </div>
                 
                  <div class="overflow-hidden h-2 mb-2 text-xs flex rounded bg-indigo-200">
                    <div style="width:75%"
                      class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-indigo-500">
                    </div>
                  </div>
                  </div>
                  <div class="">
                    <div class="mt-4 d-flex ">
                      <img class="w-10 h-10 object-cover rounded-full" src="../images/<?php echo $images[2]?>" alt="">
                      <span class="p-2" style=" color: rgb(248,255,255) ;"><?php echo $names_array[2]."(".$total_points_array[2]."points)"?></span>
                    </div>
                    <div class="text-right">
                      <span class="text-xs font-semibold inline-block text-red-600" style=" color: rgb(248,255,255) ;">
                        3rd
                      </span>
                    </div>
                 
                  <div class="overflow-hidden h-2 mb-2 text-xs flex rounded bg-gray-200">
                    <div style="width:55%"
                      class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-gray-500">
                    </div>
                  </div>
                  </div>
                  <div class="">
                    <div class="mt-4 d-flex ">
                      <img class="w-10 h-10 object-cover rounded-full" src="../images/<?php echo $images[3]?>" alt="">
                      <span class="p-2" style=" color: rgb(248,255,255) ;"><?php echo $names_array[3]."(".$total_points_array[3]."points)"?></span>
                    </div>
                    <div class="text-right">
                      <span class="text-xs font-semibold inline-block text-red-600" style=" color: rgb(248,255,255) ;">
                        4th
                      </span>
                    </div>
                 
                  <div class="overflow-hidden h-2 mb-2 text-xs flex rounded bg-yellow-200">
                    <div style="width:40%"
                      class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-yellow-500">
                    </div>
                  </div>
                  </div>
                  <div class="">
                    <div class="mt-4 d-flex ">
                      <img class="w-10 h-10 object-cover rounded-full" src="../images/<?php echo $images[4]?>" alt="">
                      <span class="p-2" style=" color: rgb(248,255,255) ;"><?php echo $names_array[4]."(".$total_points_array[4]."points)"?></span>
                    </div>
                    <div class="text-right">
                      <span class="text-xs font-semibold inline-block text-purple-600" style=" color: rgb(248,255,255) ;">
                        5th
                      </span>
                    </div>
                 
                  <div class="overflow-hidden h-2 mb-2 text-xs flex rounded bg-red-200">
                    <div style="width:30%"
                      class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-red-500">
                    </div>
                  </div>
                  </div>
              </div>
             
              
             
          
            </div>

          </div>
<?php 
$query="SELECT * FROM signin ORDER BY total_points DESC LIMIT 1";
$leader_first_query=mysqli_query($connection,$query);
$row=mysqli_fetch_assoc($leader_first_query);
$name=$row['name'];
$image=$row['image'];
$badges_earned=$row['badges_earned'];
$response_time=$row['response_time'];
$query= "SELECT count(*) as completed FROM task WHERE task_status='completed'";
$task_completed_query=mysqli_query($connection,$query);
$row=mysqli_fetch_assoc($task_completed_query);
$completed=$row['completed'];

?>

          <div class="col-md-4 rounded ">
            <div class=" p-2 rounded " style=" background-color: rgb(39,41,61) ;">
                <div class="row">
                    <div class="col-8">
                        <div class="mt-4 d-flex align-items-center">
                            <img  class="w-20 h-20 object-cover rounded-full" src="../images/<?php echo $image?>" alt="">
                            <span class="p-2 text-xl" style=" color: rgb(248,255,255) ;"><?php echo $name?></span>
                            
                            
                          </div>
                          
                    </div>
                    <div class="col-4">
                        <div class=" mt-4 flex-col justify-content-center">
                            <span class=" text-2xl text-right font-bold ml-3" style=" color: rgb(248,255,255) ;">1</span>
                            <br>
                            <span class=" text-2xl  text-right font-bold" style=" color: rgb(248,255,255) ;">Rank</span>
                      
                        </div>
                      </div>

                </div>
                

                    <div class="row">
                        <div class="col-8 flex-col px-8 justify-content-center">
                            <div class="flex-col justify-content-center mt-8">
                                <span>
                                    <i class="fas fa-medal text-5xl" style="color: rgb(248,255,255);"></i>
                                </span>
                                <br>
                                <span class="text-lg d-flex mt-2" style="color: rgb(248,255,255);">Badges Earned</span>
        
                            </div>
                        </div>

                        <div class="col-4">
                            <div class=" justify-content-center mt-8">
                        
                        
                                <span class="text-xl font-bold d-flex " style="color: rgb(248,255,255);"><?php echo $badges_earned?></span>
                            </div>
                        </div>

                    </div>
                   
                    <div class="row">
                        <div class="col-8 flex-col px-8 justify-content-center mt-8">
                            <span>
                                <i class="fas fa-tasks text-5xl" style="color: rgb(248,255,255);"></i>
                            </span>
                            <br>
                            <span class="text-lg d-flex mt-2" style="color: rgb(248,255,255);">Tasks Completed</span>
                        </div>
                        <div class="col-4">
                            <div class=" justify-content-center mt-8">
                                <span class="text-xl font-bold d-flex " style="color: rgb(248,255,255);"><?php echo $completed?></span>
                            </div>
                        </div>

                    </div>

                    <div class="row"> 
                        <div class="col-8 px-8 flex-col justify-content-center mt-8">
                            <span>
                                <i class="fas fa-stopwatch text-5xl" style="color: rgb(248,255,255);"></i>
                            </span>
                            <br>
                            <span class="text-lg d-flex mt-2" style="color: rgb(248,255,255);">Response Time</span>
                        </div>
                        <div class="col-4">
                            <div class=" justify-content-center mt-8">
                        
                        
                                <span class="text-xl font-bold d-flex " style="color: rgb(248,255,255);"><?php echo $response_time?>ms</span>
                            </div>
                        </div>

                    </div>
                    

                    

                    
                      

             
                
            </div>
          </div>

      </div>
      <!-- content div end -->
     
    </div>
  
    
  </div>

  
  
  <div class="fixed-plugin">
    <div class="dropdown show-dropdown">
      <a href="#" data-toggle="dropdown">
        <i class="fa fa-cog fa-2x"> </i>
      </a>
      <ul class="dropdown-menu">
        <li class="header-title"> Sidebar Background</li>
        <li class="adjustments-line">
          <a href="javascript:void(0)" class="switch-trigger background-color">
            <div class="badge-colors text-center">
              <span class="badge filter badge-primary active" data-color="primary"></span>
              <span class="badge filter badge-info" data-color="blue"></span>
              <span class="badge filter badge-success" data-color="green"></span>
             
            </div>
            <div class="clearfix"></div>
          </a>
        </li>
        <li class="adjustments-line text-center color-change">
          <span class="color-label">LIGHT MODE</span>
          <span class="badge light-badge mr-2"></span>
          <span class="badge dark-badge ml-2"></span>
          <span class="color-label">DARK MODE</span>
        </li>
      
      </ul>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <!-- Place this tag in your head or just before your close body tag. -->
  <script src="https://maps.googleapis.com/maps/api/js"></script>  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Black Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/black-dashboard.min.js?v=1.0.0"></script><!-- Black Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <script>
    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');
        $navbar = $('.navbar');
        $main_panel = $('.main-panel');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');
        sidebar_mini_active = true;
        white_color = false;

        window_width = $(window).width();

        fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();



        $('.fixed-plugin a').click(function(event) {
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .background-color span').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data', new_color);
          }

          if ($main_panel.length != 0) {
            $main_panel.attr('data', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data', new_color);
          }
        });

        $('.switch-sidebar-mini input').on("switchChange.bootstrapSwitch", function() {
          var $btn = $(this);

          if (sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            sidebar_mini_active = false;
            blackDashboard.showSidebarMessage('Sidebar mini deactivated...');
          } else {
            $('body').addClass('sidebar-mini');
            sidebar_mini_active = true;
            blackDashboard.showSidebarMessage('Sidebar mini activated...');
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);
        });

        $('.switch-change-color input').on("switchChange.bootstrapSwitch", function() {
          var $btn = $(this);

          if (white_color == true) {

            $('body').addClass('change-background');
            setTimeout(function() {
              $('body').removeClass('change-background');
              $('body').removeClass('white-content');
            }, 900);
            white_color = false;
          } else {

            $('body').addClass('change-background');
            setTimeout(function() {
              $('body').removeClass('change-background');
              $('body').addClass('white-content');
            }, 900);

            white_color = true;
          }


        });

        $('.light-badge').click(function() {
          $('body').addClass('white-content');
        });

        $('.dark-badge').click(function() {
          $('body').removeClass('white-content');
        });
      });
    });
  </script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      demo.initDashboardPageCharts();

    });
  </script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "black-dashboard-free"
      });
  </script>
</body>

</html>