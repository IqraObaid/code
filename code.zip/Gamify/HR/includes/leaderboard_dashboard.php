<?php
$query="SELECT * FROM signin ORDER BY total_points DESC LIMIT 3";
$leader_board_query=mysqli_query($connection,$query);
$names_array=[];
$total_points_array=[];
$images=[];

while($row=mysqli_fetch_assoc($leader_board_query)){
  array_push($names_array,$row['name']);
  array_push($total_points_array,$row['total_points']);
  array_push($images,$row['image']);
}

?>