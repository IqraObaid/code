
<?php
function GetUserThroughId($id){
    GLOBAL $connection;
    $query="SELECT * FROM signin WHERE id='$id'";
    $user_query=mysqli_query($connection,$query);
    $row=mysqli_fetch_assoc($user_query);
    return $row;

}
function AllAttendants($id){
    GLOBAL $connection;
    $query="SELECT * FROM workshop_results where workshop_id=$id";
    $attendants_query=mysqli_query($connection,$query);
    return $attendants_query;

}
function AllWorkShop(){
    GLOBAL $connection;
    $query="SELECT * FROM workshop";
    $workshop_query=mysqli_query($connection,$query);
    return $workshop_query;
}

function AllEmployees(){
    GLOBAL $connection;
    $query="SELECT * FROM signin";
    $all_employee_query=mysqli_query($connection,$query);
    return $all_employee_query;
}

function CheckUserName($username){
    GLOBAL $connection;
    $query="SELECT * FROM signin where username='$username'";
    $user_query=mysqli_query($connection,$query);
    $row=mysqli_num_rows($user_query);
    return $row;
}
function GetUserId($username){
    GLOBAL $connection;
    $query="SELECT id FROM signin WHERE username='$username'";
    $id_query=mysqli_query($connection,$query);
    $row=mysqli_fetch_assoc($id_query);
    return $row['id'];
}

function GetHiringReviews($id){
    GLOBAL $connection;
    $query="SELECT * FROM hiring_task WHERE task_assigned_to='$id'";
    $hiring_query=mysqli_query($connection,$query);
    return $hiring_query;
}

?>