
<?php
function AllWorkShop(){
    GLOBAL $connection;
    $query="SELECT * FROM workshop";
    $workshop_query=mysqli_query($connection,$query);
    return $workshop_query;
}
function GetUserId($username){
    GLOBAL $connection;
    $query="SELECT id FROM signin WHERE username='$username'";
    $id_query=mysqli_query($connection,$query);
    $row=mysqli_fetch_assoc($id_query);
    return $row['id'];
}
 function GetAllProjects($userid){
     GLOBAL $connection;
     $query="SELECT * FROM project WHERE project_assigned_to=$userid";
     $project_query=mysqli_query($connection,$query);
     return $project_query;
 }
 function GetAllSubProjects($userid){
    GLOBAL $connection;
    $query="SELECT * FROM sub_project WHERE sub_project_assignee=$userid";
    $project_query=mysqli_query($connection,$query);
    return $project_query;
}
function GetTeamLead(){
    GLOBAL $connection;
    $query="SELECT * FROM signin WHERE role='team_lead'";
    $lead_query=mysqli_query($connection,$query);
    return $lead_query;

}
function get_user_project_total_points($userid)
{
    GLOBAL $connection;
   $query="SELECT SUM(project_points) AS total_points,s.id
FROM project t,signin s 
WHERE s.id=t.project_assigned_to
AND t.project_assigned_to = '$userid'";
$reward=mysqli_query($connection,$query);
$row=mysqli_fetch_assoc($reward);
    return $row['total_points'];
}

function update_total_points($userid,$ta)
{
    GLOBAL $connection;
    
$query="select * from sub_project where sub_project_id=$ta";
 $reward=mysqli_query($connection,$query);
 $row=mysqli_fetch_assoc($reward);
 $user=$row['sub_project_assigned_to'];
 $points=$row['sub_project_points'];
 $query="select * from signin where id=$user";
 $get_user_id=mysqli_query($connection,$query);
 $row=mysqli_fetch_assoc($get_user_id);
 $total_points=$row['total_points'];
 $query="select ($total_points+ $points) as total_points from signin where id=$user";
 $add_points=mysqli_query($connection,$query);
 $row=mysqli_fetch_assoc($add_points);
 $points=$row['total_points'];
 $query="update signin set total_points=$points where id=$user";
 $point=mysqli_query($connection,$query);
 if(!$point){
    die("Query Failed".mysqli_error($connection));
  }
}
?>