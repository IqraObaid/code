<?php
    include '../includes/connection.php';
    include '../includes/functions.php';
    include '../Global/functions.php';
    session_start();
    $username=$_SESSION['id'];
    $userid=GetUserId($username);
     if(!$_SESSION['id']){
      include '../includes/session_destroy.php';
     }
    if(isset($_POST['logout'])){
      include '../includes/session_destroy.php';
    }    
    $reward_id= $_GET['id'];
    redeem_reward($userid,$reward_id)
   ?>
<?php
header("Location:http://localhost/Gamify/developer/Rewards.php");
exit();
?>
   