<div class="sidebar">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red"
      -->
      <div class="sidebar-wrapper">
        <div class="logo">
          <a href="javascript:void(0)" class="simple-text logo-mini">
            G
          </a>
          <a href="javascript:void(0)" class="simple-text logo-normal">
            GAMIFY
          </a>
        </div>
        <ul class="nav">
          <li class="active ">
            <a href="dashboard.php">
              <i class="fas fa-home"></i>
              <p>Home</p>
            </a>
          </li>
          <li>
            <a href="add_employees.php">
              <i class="fas fa-tasks"></i>
              <p>Add Employee</p>
            </a>
          </li>
          <li>
            <a href="hiring.php">
              <i class="fas fa-tasks"></i>
              <p>Hiring Task</p>
            </a>
          </li>
          <li>
            <a href="hiring_task_status.php">
              <i class="fas fa-bullhorn"></i>
              <p>Hiring Task Status</p>
            </a>
          </li>
            </a>
          </li>
          
          <li>
            <a href="workshops.php">
              <i class="fas fa-tasks"></i>
              <p>Workshops</p>
            </a>
          </li>
          <li>
            <a href="rating.php">
              <i class="fas fa-bullhorn"></i>
              <p>Rating</p>
            </a>
          </li>
            </a>
          </li>
          
         
        </ul>
      </div>
    </div>