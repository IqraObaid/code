<div class="mt-4 p-2 rounded" style=" background-color :  rgb(39,41,61);">
  <div class="mt-2 px-4 rounded">
    <span class="font-weight-bold text-lg" style=" color: rgb(248,255,255) ;">Rewards!</span>
  </div>
  <div class="d-flex justify-content-center mt-2">
    <img class="w-25 " src="https://i.pinimg.com/originals/f1/34/8e/f1348ef41147a2d398f9a152d079e4c6.png" alt="">
  </div>
  <div class="d-flex justify-content-center mt-2 align-items-center">
    <i class="fas fa-coins text-sm mr-2" style="color:rgb(248,255,255) ;"></i>
    <span class="text-xs" style="color: rgb(248,255,255);">1</span>
  </div>

  <div class="d-flex justify-content-center mt-2">
    <span class="text-sm d-flex" style="color: rgb(248,255,255);">Exchange Your Badges </span>
  </div>
  <div class="d-flex justify-content-center">
    <span class="text-sm d-flex" style="color: rgb(248,255,255);"> To Earn Rewards!</span>
  </div>
  <div class="d-flex justify-content-center mt-2 mb-2">


    <button type="button" class="btn btn-warning text-xs">Spend Badges</button>
  </div>

</div>