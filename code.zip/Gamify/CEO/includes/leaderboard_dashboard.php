<?php
$query="SELECT s.username,s.image,t.task_assigned_to,SUM(task_points) AS total_points,s.id
FROM task t,signin s 
WHERE s.id=t.task_assigned_to AND t.task_status='completed'
GROUP by task_assigned_to 
ORDER BY total_points DESC limit 6";
$leader_board_query=mysqli_query($connection,$query);
$names_array=[];
$total_points_array=[];
$images=[];
$user_id=[];
$user_name=[];
$position=[];
$count=1;

while($row=mysqli_fetch_assoc($leader_board_query)){
  array_push($total_points_array,$row['total_points']);
  array_push($images,$row['image']);
  array_push($user_id,$row['id']);
  array_push($user_name,$row['username']);
  array_push($position,$count);
  $count++;
 
}

 $colours=['bg-warning','bg-dark','bg-success','bg-secondary','bg-danger','bg-light'];
 $position=['6th','5th','4th','3rd','2nd','1st'];
$red='bg-warning';

for($i=count($user_id)-1;$i>=0;$i--){                
  ?>
  
                 <div class=" ">
                  <div class="mt-2 d-flex ">
                    <img class="w-10 h-10 object-cover rounded-full" src="../images/<?php echo $images[$i]?>" alt="">
                    <span class="p-2" style=" color: rgb(248,255,255) ;"><?php echo $user_name[$i]."Level(".($total_points_array[$i]/1000).")"?></span>
                  </div>
                  <div class="text-right">
                    <span style=" color: rgb(248,255,255) ;" class="text-xs font-semibold inline-block text-success">
                      <?php 
                      
                      if($user_id[$i]==$userid){
                        echo "YOU";
                      }else{
                        echo $position[$i];
                      }
                      ?>
                    </span>
                  </div>
               
                <div class="overflow-hidden h-2 mb-2 text-xs flex rounded bg-white">
                  <div style="width:<?php echo (($total_points_array[$i]%1000)*100)/1000 ?>%"
                    class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center <?php echo $colours[$i]?>">
                  </div>
                </div>
                </div>
                <?php } 
  
?>
